document.write('<p class="barone" style="font-size:16px;font-weight:700;padding: 10px;background-color:#525252;margin-top:150px;"><span style="color:#fff;">© Copyright - Demo Guru99 2025</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.linkedin.com/company/guru99/" target="_blank" style="background: none;"><img decoding="async" src="https://demo.guru99.com/linkedin-icon-v1.png" width="30" height="30" style="margin-right: 10px;" class=""></a><a href="https://www.facebook.com/Guru99Official" target="_blank" style="background: none;"><img decoding="async" src="https://demo.guru99.com/facebook-icon-v1.png" width="30" height="30" style="margin-right: 10px;" class=""></a><a href="https://twitter.com/guru99com" target="_blank" style="background: none;"><img decoding="async" src="https://demo.guru99.com/twitter-icon-v1.png" width="30" height="30" style="margin-right: 10px;" class=""></a><a href="https://www.guru99.com/newsletters.html" target="_blank" style="background: none;"><img decoding="async" src="https://demo.guru99.com/images/270271_email_icon.png" width="30" height="30" style="margin-right: 10px;" class=""></a> </p>');


document.write('<div class="image-container"></div>');

// Array of image objects with URL and optional link
        const images = [
            { src: 'https://demo.guru99.com/images/zoho-demoguru99.png', link: 'https://guru99.live/umr9yl' },
            { src: 'https://demo.guru99.com/images/xero-demoguru99.png', link: 'https://guru99.live/8642ux' }
        ];

        // Pick a random image
        const randomImage = images[Math.floor(Math.random() * images.length)];

        // Find the container element with the class "image-container"
        const container = document.querySelector('.image-container');

        // Insert the clickable image into the container
        container.innerHTML = `
            <a href="${randomImage.link}" target="_blank">
                <p style="text-align:center;"><img src="${randomImage.src}" alt="Random Image"></p>
            </a>
        `;
        
        
// convertbox-embed.js

(function(window, document) {
  var cb = document.createElement('script');
  cb.src = 'https://cdn.convertbox.com/convertbox/js/embed.js';
  cb.id = 'app-convertbox-script';
  cb.async = true;
  cb.dataset.uuid = 'd2df1cad-c542-4d25-b3a2-11e71e75a285';
  document.getElementsByTagName('head')[0].appendChild(cb);
})(window, document);
