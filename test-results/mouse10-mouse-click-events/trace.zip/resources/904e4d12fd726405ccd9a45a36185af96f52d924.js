
importScripts("https://www.gstatic.com/firebasejs/4.10.1/firebase.js");

var config = {
    messagingSenderId: "723051308076"
};

firebase.initializeApp(config);
var messaging = firebase.messaging();

var BASE_URL = 'api/v1/webPush/webPushTracking';

const cacheName = 'cache-v1';
const precacheResources = [
    // 'https://fonts.googleapis.com/css?family=Roboto:300,400,500,700'
    'Poppins'
];

self.addEventListener('install', (event) => {
    console.log('Service worker install event!');
    self.skipWaiting();

    event.waitUntil(
        caches.open(cacheName)
            .then(cache => cache.addAll(precacheResources))
    );
});

self.addEventListener('activate', (event) => {
    console.log('Service worker activate event!');
    event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', (event) => {
    event.respondWith(caches.match(event.request)
        .then((cachedResponse) => {
            if (cachedResponse) {
                return cachedResponse;
            }
            return fetch(event.request);
        }));
});

function sendImpression(mId, dId, tcode) {
    fetch(BASE_URL + '?did=' + dId + '&mid=' + 'h' + (parseInt(mId) + 0x00000)
            .toString(16)
            .toLowerCase() + '&tcode=' + tcode)
        .then(
            function(response) {
                if (response.status !== 200) {
                    return;
                }
                // Examine the text in the response
                response.json()
                    .then(function(data) {})
                    .catch(function(err) {});
            }
        )
        .catch(function(err) {});
}


self.addEventListener('notificationclick', function(event) {
    if (event.notification.data) {
        var mid = event.notification.data._mid || "";
        var did = event.notification.data._did || "";
        sendImpression(mid, did, 2);
        
        var url = "";
        if(event.action != ""){
            url = event.action;
        }else if(event.notification.data.click_action != ""){
            url = event.notification.data.click_action;
        }
        else{
            url = "https://www.spicejet.com";
        }
        event.waitUntil(clients.openWindow(url));
    } else {
        //console.log("Else");
        var url = "https://www.spicejet.com/";
        event.waitUntil(clients.openWindow("/"));
    }
    event.notification.close();
});

self.addEventListener('notificationclose', function(event) {
    event.notification.close();
});

self.addEventListener('push', function(event) {
    showMessage(event);
    //event.waitUntil(self.clients.claim());
});

showMessage = function(payload){
    
    var data = {};
    if (payload.data) {
        data = payload.data.json();
    
        var mid = data.data._mId || "";
        var did = data.data._dId || "";  
        
        notificationTitle = data.data.title;
        var notificationOptions = "";
        
        //console.log(data.data);
        if(data.data["Action Title 1"] == "" &&  data.data["Action Title 2"] == ""){
            notificationOptions = {
                body: data.data.body,
                icon: data.data.icon,
                image: data.data.image,
                badge: data.data.badge,
                requireInteraction: true,
                data: {
                    click_action: data.data.deepLink,
                    _mid: mid,
                    _did: did
                }
            };
        }else{
            notificationOptions = {
                body: data.data.body,
                icon: data.data.icon,
                image: data.data.image,
                badge: data.data.badge,
                requireInteraction: true,
                data: {
                    click_action: data.data.deepLink,
                    _mid: mid,
                    _did: did
                },
                actions: [
                {
                  action: data.data["Action Link 1"],
                  title: data.data["Action Title 1"],
                  icon: data.data["Action Icon 1"]
                },
                {
                  action: data.data["Action Link 2"],
                  title: data.data["Action Title 2"],
                  icon: data.data["Action Icon 2"]
                }]
            };
        }
    }

    sendImpression(mid, did, 1);
    var promiseChain  = self.registration.showNotification(notificationTitle,notificationOptions); 
    payload.waitUntil(promiseChain);

}