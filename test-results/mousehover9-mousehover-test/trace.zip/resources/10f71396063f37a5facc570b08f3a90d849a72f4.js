// preprod api URL's

// const BaseURL = 'https://preprod.mojoboxx.com/'
// const BaseAPIURL = 'https://preprodapi.mojoboxx.com/'
// const domain = 'preprod'

// prodapi Url's

const BaseURL = 'https://prod.mojoboxx.com/'
const BaseAPIURL = 'https://prodapi.mojoboxx.com/'
const domain = 'spicescreen'