
if (!sessionStorage["msgUniqueIdvalue"]) {
    sessionStorage.setItem("msgUniqueIdvalue", String(getRandom(10)))
  }
  
  var secondsCounter = 0;
  
  function incrementSeconds() {
    secondsCounter += 1;
    localStorage.setItem("totaltime", secondsCounter);
  }
  
  var cancel = setInterval(incrementSeconds, 1000);
  
  
  
  //////////////////Cookie create start////////////////////
  
  function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + exdays * 10 * 60 * 60 * 1000);
    var expires = "expires=" + d.toGMTString();
    const setCookiesData = cname + "=" + cvalue + ";" + expires + ";path=/";
    document.cookie = setCookiesData + "secure";
    return setCookiesData;
  }
  
  function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  
  // function checkCookie() {
  //   var user = getCookie("client_Unique_Id");
  //   if (user != "" && user != null) {
  //     return user;
  //   } else {
  //     user =
  //       "SJSS" +
  //       Math.floor(100000 + Math.random() * 900000) +
  //       new Date().getTime();
  //     return setCookie("client_Unique_Id", user, 1);
  //   }
  // }

  function checkCookie() {
    var user = getCookie("client_Unique_Id");
    if (user != "" && user != null) {
      return user;
    } else {
      user =
        "BAC" +
        Math.floor(100000 + Math.random() * 900000) +
        new Date().getTime();
        user = user.substring(0, 14);
      return setCookie("client_Unique_Id", user, 1);
    }
  }
  
  /////////////////cookie create end //////////////////////
  
  // var client_unq_mac = getCookie("client_Unique_Id");
  var client_unque_mac = checkCookie();
  if (client_unque_mac.includes(";")) {
    // console.log(client_unq_mac)
    let splitcookie = client_unque_mac.split(";");
    // console.log(splitcookie)
    let splitcookie2 = splitcookie[0];
    // console.log(splitcookie2)
    let splitcookie3 = splitcookie2.split("=")
    // console.log(splitcookie3)
    var splitcookie4 = splitcookie3[1]
    // console.log(splitcookie4);
    client_unque_mac = splitcookie4;
  }
  
  function analyticTracking(adid, admenu, adtype) {
    let url2 = adid;
    let advtype = adtype;
    let menutype = admenu;
    // var tempId = parseInt(getIdTemp());
    var id = parseInt(url2);
    var type = advtype;
    var timeDuration = new Date().getTime();
    let msisdn = ""
    dataJ = {
      "tracking": [{
        "id": id,
        "dataLimitReached": false,
        "destination": "WEB",
        "duration": 0,
        "eventId": timeDuration,
        "ip": "WEB",
        "journeyId": "WEB",
        "latitude": "WEB",
        "longitude": "WEB",
        "mac": client_unque_mac,
        // "mac": "WEB",
        "menu": menutype,
        "model": "WEB",
        "msisdn": "WEB",
        "platform_duration": localStorage['totaltime'],
        "play_duration": "N/A",
        "reg_id": "WEB",
        "session_id": "WEB",
        "source": "Bookairportcab",
        "timestamp": timeDuration,
        "trackingDetails": "click",
        "type": type,
        "user_agent": navigator.userAgent.toLowerCase(),
        "platform": "Bookairportcab"
      }],
      "_interface": "AN",
      "deviceId": "8e9082ae95135228",
      "model": "XIAOMIREDMINOTE7S",
      "package": "com.vuscreen.IFE.hosta",
      "partner": "dbrovmhalfs83i130k6u9fh0sj",
      "reg_id": "b6e0c866c81a9aa73b01b8c80c46b65498dedfd3f8e1e53e7359aba29c268499",
      "serverDeviceId": "",
      "sync_type": "WEB",
      "version": "1.7",
      "versionCode": 7
    };
  
    $.ajax({
      contentType: 'application/json',
      Accept: 'application/json',
      data: JSON.stringify(dataJ),
      dataType: 'json',
      success: function (res) {
        // console.log(res)
      },
      error: function () {
        console.log("menuTracking failed");
      },
      type: 'POST',
      url: BaseAPIURL + domain + '/webapi/vuscreen/spicejetTrack'
    });
  }
  
  function getRandom(length) {
    return Math.floor(Math.pow(10, length - 1) + Math.random() * 9 * Math.pow(10, length - 1));
  }

  function Track_analytics(PNR, Name, Dest, source, STA, STD, mobile, OTP, title) {
    let emailId = "hello@mojoboxx.com";


    if (sessionStorage["PrefillcustomerData"]) {
      let parseData = JSON.parse(decryptStorage(sessionStorage["PrefillcustomerData"]));
  
      let name = parseData.name.includes("/")
        ? parseData.name.replace("/", " ")
        : parseData.name;
  
      Name = name;
      mobile = parseData?.phone;
      emailId = parseData?.email;
      Dest = String(parseData.city).split("-")[1];
      source = String(parseData.city).split("-")[0];
      STA = parseData?.STA;
      STD = parseData?.STD;
      PNR = parseData?.pnr;
      var prefillAmount = parseData?.prepaid_payment;
      OTP = parseData?.FlightNum;
      rph = parseData?.rph
    }
    dataJ = {
      "clubMember": [{
        "type": sessionStorage["MojoboxxURL_booking"] == "Mojoboxx" ? "SPICEJET_MICE_mojoboxx Analytics" : sessionStorage["MojoboxxURL_booking"] == "Facebook" ? "Facebook" : localStorage["TravelType"] == "International" ? "SPICEJET_MICE_International Analytics" : "SPICEJET MICE Analytics",
        "user_name": Name,
        "last_name": "Customer",
        "mobile": mobile,
        "email": emailId,
        "time": Date.now(),
        "sendLeadSms":"true",
        "title": sessionStorage["MojoboxxURL_booking"] == "Mojoboxx" ? "SPICEJET_MICE_mojoboxx_departure" : sessionStorage["MojoboxxURL_booking"] == "Facebook" ? "BAC_Facebook" : title,
        "mac_address": client_unque_mac,
        "category": "CAB",
        "msgUniqueId": getRandom(10),
        "from_city": source,
        "source": source,
        "to_city": Dest,
        "destination": Dest,
        "latitude": "",
        "longitude": "",
        "isDeparture": 1,
        "STD": STD,
        "STA": STA,
        "OTP": OTP,
        "pnr": PNR,
        "status": sessionStorage["MojoboxxURL_booking"] == "Mojoboxx" ? "SPICEJET_MICE_mojoboxx_departure" : sessionStorage["MojoboxxURL_booking"] == "Facebook" ? "BAC_Facebook" : title,
      }]
    };
    if (sessionStorage["PrefillcustomerData"]) {
      let parseData = JSON.parse(decryptStorage(sessionStorage["PrefillcustomerData"]));
      dataJ.clubMember[0]["cab_category"] = parseData?.uid;
      dataJ.clubMember[0]["model"] = parseData?.uniqueId;
      dataJ.clubMember[0]["journey_id"] = parseData?.rph;
      dataJ.clubMember[0]["bySystem"] = parseData?.bySystem;
    }
  
    $.ajax({
      contentType: 'application/json',
      Accept: 'application/json',
      data: JSON.stringify(dataJ),
      dataType: 'json',
      success: function (response) {
        // console.log(response);
      },
      error: function () {
        console.log("Cab Tracking failed");
      },
      type: 'POST',
      url: BaseURL + domain + '/webapi/departureAnalytics'
    });
    
  }
  
  async function Track_LoadAnalytics(mobile, pageName, title, Name, source_city, citycode, Terminal, Dest_city,
    source_lat, source_long, dest_lat, dest_long, pickup_date, pickuptime, coupon_code = '', email = '', partner = '', KMNum = '', content_id = '', cabtype) {
    if (sessionStorage["PrefillcustomerData"]) {
      let parseData = JSON.parse(decryptStorage(sessionStorage["PrefillcustomerData"]));
  
      let name = parseData.name.includes("/")
        ? parseData.name.replace("/", " ")
        : parseData.name;
  
      Name = name;
      mobile = parseData?.phone;
      email = parseData?.email;
      var prefillAmount = parseData?.prepaid_payment;
    }

    dataJ = {
      "mobile": mobile,
      "category": "cab",
      "pagename": pageName,
      "title": "Ride",
      "type": sessionStorage["MojoboxxURL_booking"] == "Mojoboxx" ? "SPICEJET_MICE_mojoboxx page load" : sessionStorage["MojoboxxURL_booking"] == "Facebook" ? "Facebook" : localStorage["TravelType"] == "International" ? "SPICEJET_MICE_International page load" : "SPICEJET MICE page load",
      "user_name": Name,
      "last_name": "Customer",
      "source_city": source_city,
      "city_code": citycode,
      "terminal": Terminal,
      "destination_city": Dest_city,
      "source_lat": source_lat,
      "source_long": source_long,
      "destination_lat": dest_lat,
      "destination_long": dest_long,
      "pickup_date": pickup_date,
      "pickup_time": pickuptime,
      "cabcard_show": KMNum,
      "msgUniqueId": sessionStorage["msgUniqueIdvalue"],
      "mac_address": client_unque_mac,
      "sendLeadSms": "true",
      "coupon_code": coupon_code,
      "email_Id": email,
      "partnername": partner,
      "cabfare": content_id,
      'cabtype': cabtype,
    };
     sessionStorage.setItem("DataR",dataJ)
    $.ajax({
      contentType: 'application/json',
      Accept: 'application/json',
      data: JSON.stringify(dataJ),
      dataType: 'json',
      success: function (response) {
        //  console.log(response);
      },
      error: function () {
        console.log("Cab Tracking failed");
      },
      type: 'POST',
      url: BaseAPIURL + domain + '/webapi/cab_analyticsApi'
    });

  }

  
  // Function used to send map location character count /////////
  async function sendMapCountTracking(count, mapkey) {
  
    let BodyPayload = {
      "key_name": mapkey,
      "platform": "spicejet",
      "count": count
    };
  
    const json = BodyPayload
    const key = 'SPICE%SCREEN%BAC#SECERET%$#&)';
    const iv = 'SPICE$MOJO$BOXX$BAC**$#';
    const encrypted = CryptoJS.AES.encrypt(JSON.stringify(json), key, { iv }).toString();
  
    let payload = { "encryptData": encrypted }
  
    $.ajax({
      contentType: 'application/json',
      Accept: 'application/json',
      data: JSON.stringify(payload),
      dataType: 'json',
      success: function (response) {
        // console.log(response);
      },
      error: function () {
        console.log("Cab Tracking failed");
      },
      type: 'POST',
      url: BaseAPIURL + domain + '/webapi/InsertMap_Search'
    });
  }