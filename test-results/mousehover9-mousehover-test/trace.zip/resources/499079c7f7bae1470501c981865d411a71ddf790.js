function encryptStorage(storage) {
    let StringifyStorage = JSON.stringify(storage)
    const privatekey = "Ya0#-$hf90-A78T-90mki-mop7yl"
    const encryptedText = CryptoJS.AES.encrypt(StringifyStorage, privatekey).toString();
    return encryptedText
}

function decryptStorage(encryptedStorage) {
    const privatekey = "Ya0#-$hf90-A78T-90mki-mop7yl";
    const decryptedBytes = CryptoJS.AES.decrypt(encryptedStorage, privatekey);
    const plainStorageValue = decryptedBytes.toString(CryptoJS.enc.Utf8);
    return plainStorageValue;
}


const isArrival = sessionStorage.getItem("AirportRideType") === "arrival";

const arrival = document.getElementById("Arrival");
const departure = document.getElementById("Airport Transfers");

arrival.classList.toggle("selected", isArrival);
departure.classList.toggle("selected", !isArrival);

arrival.checked = isArrival;
departure.checked = !isArrival;


// get pickup date and time
// function getpickupdate() {
//     let timeval;
//     var time = $(".timepicker").val();
//     var status = time.includes("M");
//     if (status) {
//         var hours = Number(time.match(/^(\d+)/)[1]);
//         var minutes = Number(time.match(/:(\d+)/)[1]);
//         var AMPM = time.match(/\s(.*)$/)[1];
//         if (AMPM == "PM" && hours < 12) hours = hours + 12;

//         if (AMPM == "AM" && hours == 12) hours = hours - 12;

//         var sHours = hours.toString();
//         var sMinutes = minutes.toString();
//         if (hours < 10) sHours = "0" + sHours;

//         if (minutes < 10) sMinutes = "0" + sMinutes;

//         var statusTime = sHours + ":" + sMinutes;
//         timeval = statusTime;
//     } else {
//         timeval = $(".timepicker").val();
//     }

//     let pickup_time =
//         moment($("#datepicker").val(), [
//             "DD-MM-YYYY",
//             "YYYY-MM-DD",
//             "DD/MM/YYYY",
//         ]).format("YYYY-MM-DD") +
//         " " +
//         timeval;
//     return pickup_time;
// }