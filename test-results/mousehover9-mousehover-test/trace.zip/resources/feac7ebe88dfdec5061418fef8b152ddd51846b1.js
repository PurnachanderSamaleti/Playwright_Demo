(function() {
	//console.log(navigator);	
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            /*Change this service worker path to the location of your own service worker file*/
            navigator.serviceWorker.register('/sw.js', {
                    scope: "/"
                })
                .then(function(registration) {
                    messaging
                        .useServiceWorker(registration);
						console.log("SW Register");
						//deleteToken();
                    resetUI();
                })
                .catch(function(err) {
                    // registration failed :(
                    console.log('ServiceWorker registration failed: ', err);
                });
        });
    }

    var MOBILE_APP_UUID = '24DFD5FA-623E-419D-940B-7315BD22C7AA';
	
	var BASE_URL = 'api/v1/webPush';
    var TIME_OUT = 2000;
    var config = {
		messagingSenderId: "723051308076"
    };

    var util = {
        getLang: function() {
            return navigator.language;
        },
        getOs: function() {
            return navigator.platform;
        },
        getBrowser: function() {
            navigator.sayswho = (function() {
                var ua = navigator.userAgent,
                    tem,
                    M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
                if (/trident/i.test(M[1])) {
                    tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                    return 'IE ' + (tem[1] || '');
                }
                if (M[1] === 'Chrome') {
                    tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
                    if (tem != null) return tem.slice(1)
                        .join(' ')
                        .replace('OPR', 'Opera');
                }
                M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
                if ((tem = ua.match(/version\/(\d+)/i)) != null) M.splice(1, 1, tem[1]);
                return M.join(' ');
            })();
            return navigator.sayswho;
        },
        /*getCustID: function() {
            if (typeof digitalData !== 'undefined' && digitalData && digitalData.user) {
                return digitalData.user.userID
            }
            return "";
        },
        getMobileNumber: function() {
            if (typeof digitalData !== 'undefined' && digitalData && digitalData.user) {
                return digitalData.user.userID
            }
            return "";
        },*/
        getUserKey: function() {
            if (typeof digitalData !== 'undefined' && digitalData && digitalData.user) {
                return digitalData.user.userID
            }
            return "";
        },
        getUserAgent: function() {
            return navigator.userAgent;
        },
        getMCID: function() {
            return typeof _satellite !== 'undefined' ? _satellite.getVisitorId().getMarketingCloudVisitorID() : "null";
        },
        validateEmail: function(email) {
            var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(String(email)
                .toLowerCase());
        },
        getDeviceDetails: function() {
            var unknown = '-';

            // screen
            var screenSize = '';
            if (screen.width) {
                width = (screen.width) ? screen.width : '';
                height = (screen.height) ? screen.height : '';
                screenSize += '' + width + " x " + height;
            }

            // browser
            var nVer = navigator.appVersion;
            var nAgt = navigator.userAgent;
            var browser = navigator.appName;
            var version = '' + parseFloat(navigator.appVersion);
            var majorVersion = parseInt(navigator.appVersion, 10);
            var nameOffset, verOffset, ix;

            // Opera
            if ((verOffset = nAgt.indexOf('Opera')) != -1) {
                browser = 'Opera';
                version = nAgt.substring(verOffset + 6);
                if ((verOffset = nAgt.indexOf('Version')) != -1) {
                    version = nAgt.substring(verOffset + 8);
                }
            }
            // Opera Next
            if ((verOffset = nAgt.indexOf('OPR')) != -1) {
                browser = 'Opera';
                version = nAgt.substring(verOffset + 4);
            }
            // Edge
            else if ((verOffset = nAgt.indexOf('Edge')) != -1) {
                browser = 'Microsoft Edge';
                version = nAgt.substring(verOffset + 5);
            }
            // MSIE
            else if ((verOffset = nAgt.indexOf('MSIE')) != -1) {
                browser = 'Microsoft Internet Explorer';
                version = nAgt.substring(verOffset + 5);
            }
            // Chrome
            else if ((verOffset = nAgt.indexOf('Chrome')) != -1) {
                browser = 'Chrome';
                version = nAgt.substring(verOffset + 7);
            }
            // Safari
            else if ((verOffset = nAgt.indexOf('Safari')) != -1) {
                browser = 'Safari';
                version = nAgt.substring(verOffset + 7);
                if ((verOffset = nAgt.indexOf('Version')) != -1) {
                    version = nAgt.substring(verOffset + 8);
                }
            }
            // Firefox
            else if ((verOffset = nAgt.indexOf('Firefox')) != -1) {
                browser = 'Firefox';
                version = nAgt.substring(verOffset + 8);
            }
            // MSIE 11+
            else if (nAgt.indexOf('Trident/') != -1) {
                browser = 'Microsoft Internet Explorer';
                version = nAgt.substring(nAgt.indexOf('rv:') + 3);
            }
            // Other browsers
            else if ((nameOffset = nAgt.lastIndexOf(' ') + 1) < (verOffset = nAgt.lastIndexOf('/'))) {
                browser = nAgt.substring(nameOffset, verOffset);
                version = nAgt.substring(verOffset + 1);
                if (browser.toLowerCase() == browser.toUpperCase()) {
                    browser = navigator.appName;
                }
            }
            // trim the version string
            if ((ix = version.indexOf(';')) != -1) version = version.substring(0, ix);
            if ((ix = version.indexOf(' ')) != -1) version = version.substring(0, ix);
            if ((ix = version.indexOf(')')) != -1) version = version.substring(0, ix);

            majorVersion = parseInt('' + version, 10);
            if (isNaN(majorVersion)) {
                version = '' + parseFloat(navigator.appVersion);
                majorVersion = parseInt(navigator.appVersion, 10);
            }

            // mobile version
            var mobile = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/.test(nVer);

            // cookie
            var cookieEnabled = (navigator.cookieEnabled) ? true : false;

            if (typeof navigator.cookieEnabled == 'undefined' && !cookieEnabled) {
                document.cookie = 'testcookie';
                cookieEnabled = (document.cookie.indexOf('testcookie') != -1) ? true : false;
            }

            // system
            var os = unknown;

            var clientStrings = [{
                    s: 'Windows 10',
                    r: /(Windows 10.0|Windows NT 10.0)/
                },
                {
                    s: 'Windows 8.1',
                    r: /(Windows 8.1|Windows NT 6.3)/
                },
                {
                    s: 'Windows 8',
                    r: /(Windows 8|Windows NT 6.2)/
                },
                {
                    s: 'Windows 7',
                    r: /(Windows 7|Windows NT 6.1)/
                },
                {
                    s: 'Windows Vista',
                    r: /Windows NT 6.0/
                },
                {
                    s: 'Windows Server 2003',
                    r: /Windows NT 5.2/
                },
                {
                    s: 'Windows XP',
                    r: /(Windows NT 5.1|Windows XP)/
                },
                {
                    s: 'Windows 2000',
                    r: /(Windows NT 5.0|Windows 2000)/
                },
                {
                    s: 'Windows ME',
                    r: /(Win 9x 4.90|Windows ME)/
                },
                {
                    s: 'Windows 98',
                    r: /(Windows 98|Win98)/
                },
                {
                    s: 'Windows 95',
                    r: /(Windows 95|Win95|Windows_95)/
                },
                {
                    s: 'Windows NT 4.0',
                    r: /(Windows NT 4.0|WinNT4.0|WinNT|Windows NT)/
                },
                {
                    s: 'Windows CE',
                    r: /Windows CE/
                },
                {
                    s: 'Windows 3.11',
                    r: /Win16/
                },
                {
                    s: 'Android',
                    r: /Android/
                },
                {
                    s: 'Open BSD',
                    r: /OpenBSD/
                },
                {
                    s: 'Sun OS',
                    r: /SunOS/
                },
                {
                    s: 'Linux',
                    r: /(Linux|X11)/
                },
                {
                    s: 'iOS',
                    r: /(iPhone|iPad|iPod)/
                },
                {
                    s: 'Mac OS X',
                    r: /Mac OS X/
                },
                {
                    s: 'Mac OS',
                    r: /(MacPPC|MacIntel|Mac_PowerPC|Macintosh)/
                },
                {
                    s: 'QNX',
                    r: /QNX/
                },
                {
                    s: 'UNIX',
                    r: /UNIX/
                },
                {
                    s: 'BeOS',
                    r: /BeOS/
                },
                {
                    s: 'OS/2',
                    r: /OS\/2/
                },
                {
                    s: 'Search Bot',
                    r: /(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask Jeeves\/Teoma|ia_archiver)/
                }
            ];
            for (var id in clientStrings) {
                var cs = clientStrings[id];
                if (cs.r.test(nAgt)) {
                    os = cs.s;
                    break;
                }
            }

            var osVersion = unknown;

            if (/Windows/.test(os)) {
                osVersion = /Windows (.*)/.exec(os)[1];
                os = 'Windows';
            }

            switch (os) {
                case 'Mac OS X':
                    osVersion = /Mac OS X (10[\.\_\d]+)/.exec(nAgt)[1];
                    break;

                case 'Android':
                    osVersion = /Android ([\.\_\d]+)/.exec(nAgt)[1];
                    break;

                case 'iOS':
                    osVersion = /OS (\d+)_(\d+)_?(\d+)?/.exec(nVer);
                    osVersion = osVersion[1] + '.' + osVersion[2] + '.' + (osVersion[3] | 0);
                    break;
            }

            // flash (you'll need to include swfobject)
            var flashVersion = 'no check';
            if (typeof swfobject != 'undefined') {
                var fv = swfobject.getFlashPlayerVersion();
                if (fv.major > 0) {
                    flashVersion = fv.major + '.' + fv.minor + ' r' + fv.release;
                } else {
                    flashVersion = unknown;
                }
            }
            var jscd = {
                screen: screenSize,
                browser: browser,
                browserVersion: version,
                browserMajorVersion: majorVersion,
                mobile: mobile,
                os: os,
                osVersion: osVersion,
                cookies: cookieEnabled,
                flashVersion: flashVersion
            };
            return jscd;
        }
    };

    firebase.initializeApp(config);

    var messaging = firebase.messaging();

    messaging.onTokenRefresh(function() {
        messaging.getToken()
            .then(function(refreshedToken) {
				console.log("Refresh Token : " + refreshedToken);
                setTokenSentToServer(false);
                sendTokenToServer(refreshedToken);
                resetUI();

            })
            .catch(function(err) {
                //console.log('Unable to retrieve refreshed token ', err);
            });
    });

    messaging.onMessage(function(payload) {
        var mid = payload.data._mId || "";
        var did = payload.data._dId || "";
		//console.log(payload.data);	
        var notificationTitle = payload.data.title;
        var notificationOptions = {
            body: payload.data.body,
            icon: payload.data.icon,
            image: payload.data.image,
            requireInteraction: true,
            data: {
                click_action: payload.data.click_action,
                _mid: mid,
                _did: did
            }
        };

        sendImpression(did, mid, 1);
        var notification = new Notification(notificationTitle, notificationOptions);
        notification.onclose = function(event) {}
        notification.onclick = function(event) {
            if (event.currentTarget.data) {
                var mid = event.currentTarget.data._mid || "";
                var did = event.currentTarget.data._did || "";
                var url = event.currentTarget.data.click_action || "https://www.google.com";

                sendImpression(did, mid, 2);
                setTimeout(function() {
                    window.open(url);
                }, 500);
            } else {
            }

            if (notification) {
                notification.close();
            }
        }
    });

	function processRequestPost(config) {
        //console.log("request being sent..");
        return new Promise(function(resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open(config.method, config.url);
            xhr.setRequestHeader("Content-Type", "application/json");
			xhr.send(JSON.stringify(config.data));
            xhr.onload = function() {
                resolve(xhr.responseText)
            };
            xhr.onerror = function() {
                reject(xhr.statusText)
            };
            xhr.send();
        });
    }

    function processRequest(config) {
        //console.log("request being sent..");
        return new Promise(function(resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open(config.method, config.url);
            xhr.onload = function() {
                resolve(xhr.responseText)
            };
            xhr.onerror = function() {
                reject(xhr.statusText)
            };
            xhr.send();
        });
    }

    function resetUI() {
		messaging.getToken()
            .then(function(currentToken) {
                if (currentToken) {
                    //console.log("logging token  -> ", currentToken);
                    sendTokenToServer(currentToken);
                    var devDetails = util.getDeviceDetails();
                    var browserDetail = util.getBrowser();
                    var browser = browserDetail.split(" ")[0];
                    var browserVer = browserDetail.split(" ")[1];
					//console.log("Browser Version: " + browserVer);
                } else {
                    // Show permission request.                 
                    logMessage('No Instance ID token available. Request permission to generate one.');
                    // Show permission UI.                 
                    // requestPermission();
                    setTokenSentToServer(false);
                }
            })
            .catch(function(err) {
                //console.log('An error occurred while retrieving token. ', err);
                setTokenSentToServer(false);
            });
    } // [END get_token]

    function logMessage(message) {
        //console.log(message);
    }

    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function pollForDigitalData(currentToken) {
        if (getCookie("userName") !== "") {
            /*logged in*/

            if (typeof digitalData !== 'undefined') {
                //console.log("Token sent with user data");
                var devDetails = util.getDeviceDetails();
                sendClientToken(currentToken, util.getUserKey(), util.getMCID(), util.getLang(), devDetails.os, devDetails.osVersion, devDetails.browser, devDetails.browserVer, util.getUserAgent());
                setTokenSentToServer(true);
                /*if (util.getCustID() !== "" && util.getCustID() !== null) {
                    setUserInfoSentToServer(true);
                }*/
            } 
        } else {
            /*not logged in*/
            //console.log("Token sent without user data");
            var devDetails = util.getDeviceDetails();
            sendClientToken(currentToken, util.getUserKey(), util.getMCID(), util.getLang(), devDetails.os, devDetails.osVersion, devDetails.browser, devDetails.browserVer, util.getUserAgent());
            setTokenSentToServer(true);
        }
    }

    function sendTokenToServer(currentToken) {
        if (!isTokenSentToServer() || (!isUserInfoSentToServer() && getCookie("userName") !== "")) {
            logMessage('Sending token to server...');
            pollForDigitalData(currentToken);
        } else {
            logMessage('Token already sent to server so won\'t send it again ' +
                'unless it changes');
        }
    }

    function isTokenSentToServer() {
        return window.localStorage.getItem('sentToServer') == 1;
    }

    function setTokenSentToServer(sent) {
        window.localStorage.setItem('sentToServer', sent ? 1 : 0);
    }

    function isUserInfoSentToServer() {
        return window.localStorage.getItem('sentUserInfoToServer') == 1;
    }

    function setUserInfoSentToServer(sent) {
        window.localStorage.setItem('sentUserInfoToServer', sent ? 1 : 0);
    }

    function requestPermission() {
        logMessage('NOT Requesting permission...');
        // [START request_permission]
        // messaging.requestPermission()
        //     .then(function() {
        //         logMessage('Notification permission granted.');
        //         // TODO(developer): Retrieve an Instance ID token for use with FCM.
        //         // [START_EXCLUDE]
        //         // In many cases once an app has been granted notification permission, it
        //         // should update its UI reflecting this.
        //         resetUI();
        //         // [END_EXCLUDE]
        //     })
        //     .catch(function(err) {
        //         logMessage('Unable to get permission to notify.', err);
        //     });
        // [END request_permission]
    }

    function deleteToken() {
        // Delete Instance ID token.
        // [START delete_token]
        messaging.getToken()
            .then(function(currentToken) {
                messaging.deleteToken(currentToken)
                    .then(function() {
                        logMessage('Token deleted.');
                        setTokenSentToServer(false);
                        // [START_EXCLUDE]
                        // Once token is deleted update UI.
                        resetUI();
                        // [END_EXCLUDE]
                    })
                    .catch(function(err) {
                        logMessage('Unable to delete token. ' + JSON.stringify(err));
                    });
                // [END delete_token]
            })
            .catch(function(err) {
                logMessage('Error retrieving Instance ID token. ', err);
            });
    }

    /*
    @params - Client Token, Unique User ID, Experience Cloud ID, Browser Language, OS, OS Version, Browser, Browser Version, User Agent
    */

    function sendClientToken(clientToken, userKey, mcid, language, os, osVer, browser, browserVer, ua) {
		var data = {"acui":MOBILE_APP_UUID,"ukey":userKey,"ctok":clientToken,"os":os,"osv":osVer,"osl":language,"manf":browser,"manfv":browserVer,"ecid":mcid};
		//console.log(data);
        var options = {
            url: BASE_URL + '/registerMobile',
            method: 'POST',
			data: data
        };

        processRequestPost(options)
            .then(function(res) {
                logMessage('Response is : ' + JSON.stringify(res));
            }, function(err) {
                logMessage('some error occurred --> ' + JSON.stringify(err));
            });
    }

    function showNotification(body) {
        // Notification.requestPermission(function(result) {
        //     if (result === 'granted') {
        //         navigator.serviceWorker.ready.then(function(registration) {

        //             registration.showNotification(body.title, body);
        //         });
        //     }
        // });
    }

    function sendImpression(deliveryid, messageid, tcode) {
        logMessage("MID : " + messageid + " --- DID : " + deliveryid);
        var options = {
            url: BASE_URL + '/webPushTracking?did=' + deliveryid + '&mid=' + 'h' + (parseInt(messageid) + 0x00000)
                .toString(16)
                .toLowerCase() + '&tcode=' + tcode,
            method: 'GET'
        };
        processRequest(options)
            .then(function() {
                logMessage('sent to server --> ' + JSON.stringify(options));
            }, function(err) {
                logMessage('some error occurred -->' + JSON.stringify(err));
            });
    } // $(document)
    //     .ready(function() {
    //         resetUI();
    //     });
})();